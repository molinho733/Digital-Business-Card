import React from 'react'

export default function Interest() {
    return (
        <div className="container">
            <h3 className="article--title">Interests</h3>
            <p className="article--description">Food expert. Music scholar. Reader. Internet fanatic. Bacon buff. Entrepreneur. Travel geek. Pop culture ninja. Coffee fanatic.</p>
        </div>
    )
}