import React from "react"

export default function Footer() {
    return (
       <footer>
            <div className="icon"><a href="#"><i className="fa-brands fa-twitter"></i></a></div>
            <div className="icon"><a href="#"><i className="fa-brands fa-facebook"></i></a></div>
            <div className="icon"><a href="#"><i className="fa-brands fa-instagram"></i></a></div>
            <div className="icon"><a href="#"><i className="fa-brands fa-github"></i></a></div>    
       </footer>
    )
}