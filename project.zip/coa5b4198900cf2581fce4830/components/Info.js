import React from "react"

export default function Info() {
    return (
       <div className="info">
            <img className="info--img" src="https://profile-images.xing.com/images/c7e099526f28418b23bbeab598d0cea9-3/philipp-m%C3%B6ller.1024x1024.jpg" alt="a picture of me in a suit"/>
            <h1 className="info--name">Philipp Möller</h1>
            <h3 className="info--title">Front End Developer</h3>
            <a className="info--homepage" href="#">philippmoeller.dev</a>
            <div className="info--buttons">
                <a className="button email" href="#" rel="Email link">
                    <i className="fa-solid fa-envelope"></i><span>Email</span>
                </a>
                <a className="button linkedIn" href="#" rel="Email link">
                    <i className="fa-brands fa-linkedin"></i><span>LinkedIn</span>
                </a>
            </div>
       </div>
    )
}